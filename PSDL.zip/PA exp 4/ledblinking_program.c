// NMAE:- Atharva Dasarwar.
// ROLL NO:- 12. SE-IT.


#include <p18f4580.h>
void T0Delay(void);
#define mybit PORTBbits.RB4
void main (void){
	while(1){
		mybit = 1;
		T0Delay();
		mybit = 0;
		T0Delay();
	}
}

void T0Delay(void){
	T0CON = 0x01;
	TMR0H = 0XFF;
	TMR0L = 0XEE;
	T0CONbits.TMR0ON = 1;
	while(INTCONbits.TMR0IF == 0)
	T0CONbits.TMR0ON = 1;
	INTCONbits.TMR0IF = 0;
}
